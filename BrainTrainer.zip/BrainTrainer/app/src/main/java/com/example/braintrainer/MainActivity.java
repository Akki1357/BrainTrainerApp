package com.example.braintrainer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;


public class MainActivity extends AppCompatActivity {
    TextView timer, sum, score , ansView;
    Button option1, option2, option3, option4 , playbutton;
    Random rand = new Random();
    ArrayList<Integer> answer = new ArrayList<Integer>(4);
    int locationOfCorrectAnswer;
    int scory =0;
    int numOfGamePlayed=0;





    public void chooseAnswer(View view){

        if(String.valueOf(locationOfCorrectAnswer).equals(view.getTag().toString())){
            ansView.setText("Correct!!");
            scory++;
        }
        else {
            ansView.setText("Wrong!!");
        }
        numOfGamePlayed++;

        score.setText(scory + "/" + numOfGamePlayed);
        newQuestion();
    }

    public void playAgain(View view){
        scory=0;
        numOfGamePlayed=0;
        timer.setText("30s");
        score.setText(scory + "/" + numOfGamePlayed);
        ansView.setText(" ");
        newQuestion();
        playbutton.setVisibility(View.INVISIBLE);
        new CountDownTimer(5000, 1000) {
            public void onTick(long millisUntilFinished) {
                timer.setText("" + millisUntilFinished / 1000 + "s");
            }
            public void onFinish() {
                ansView.setText("Done!");
                timer.setText("0s");
                playbutton.setVisibility(View.VISIBLE);

            }

        }.start();
    }

    public  void newQuestion(){
        int a = rand.nextInt(21);
        int b = rand.nextInt(21);
        sum.setText(a + "+" + b);

        locationOfCorrectAnswer = rand.nextInt(4);

        answer.clear();
        for (int i = 0; i < 4; i++) {
            if (i == locationOfCorrectAnswer) {
                answer.add(a+b);
            } else {
                int wrongAnswer = rand.nextInt(41);
                while(wrongAnswer == a+b){
                    wrongAnswer = rand.nextInt(41);
                }
                answer.add(wrongAnswer);
            }
        }
        option1.setText(String.valueOf(answer.get(0)));
        option2.setText(String.valueOf(answer.get(1)));
        option3.setText(String.valueOf(answer.get(2)));
        option4.setText(String.valueOf(answer.get(3)));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timer = findViewById(R.id.timer);
        sum = findViewById(R.id.sum);
        ansView = findViewById(R.id.ansView);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        playbutton = findViewById(R.id.playbutton);
        score= findViewById(R.id.score);

        newQuestion();

        playAgain(option4 = findViewById(R.id.option4));






    }
}
